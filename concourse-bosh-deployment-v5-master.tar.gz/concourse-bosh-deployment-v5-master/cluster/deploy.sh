## deploy concoursee with credhub collocated with concourse ewb on vsphere
## concourse.pcfdemo.net 10.10.10.210

bosh -e d deploy -n --no-redact -d concourse5 concourse.yml \
  -l ../versions.yml \
  -o operations/basic-auth.yml \
  -o operations/privileged-http.yml \
  -o operations/privileged-https.yml \
  -o operations/tls.yml \
  -o operations/tls-vars.yml \
  -o operations/scale.yml \
  -o operations/add-credhub-uaa-to-web.yml \
  -o operations/static-web.yml \
  --var web_ip=10.10.10.220 \
  --var network_name=concourse \
  --var web_vm_type=medium \
  --var db_vm_type=medium \
  --var worker_vm_type=medium.disk \
  --var db_persistent_disk_type=db \
  --var web_instances=1 \
  --var worker_instances=1 \
  --var deployment_name=concourse5 \
  --var external_host=concourse.pcfdemo.net \
  --var external_url=https://concourse.pcfdemo.net \
  --var local_user.username=admin \
  --var local_user.password=PASS 
